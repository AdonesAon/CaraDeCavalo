
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class ProdutoDAO extends DataBaseDAO {
    
      public ProdutoDAO () throws Exception{}
    
    public ArrayList<Produto> getLista() throws Exception{
        
        ArrayList<Produto> lista = new ArrayList<Produto>();
        String SQL = "SELECT * FROM produto ";
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(SQL);
        while(rs.next()){
            Produto pr = new Produto();
            pr.setIdProduto(rs.getInt("idProduto"));
            pr.setNome(rs.getString("nome"));
            pr.setPreco(rs.getDouble("preco"));
            pr.setDesc(rs.getString("desc"));
            pr.setQtdEstoque(rs.getInt("qtdEstoque"));
            lista.add(pr);
        }
        this.desconectar();
        return lista;
    }
    
      
    
    public boolean gravar(Produto pr){
        try{
            String sql;
            this.conectar();
            if(pr.getIdProduto()==0){
                sql = "INSERT  INTO produto (nome, preco, desc, qtdEstoque) VALUES(?, ?, ?, ?)";
            }else{
                sql = "UPDATE produto SET nome=?, preco=?, desc=?, qtdEstoque=? WHERE idProduto=?";
            }
            
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1,pr.getNome());
            pstm.setDouble(2,pr.getPreco());
            pstm.setString(3,pr.getDesc());
            pstm.setInt(4,pr.getQtdEstoque());
            if(pr.getIdProduto()>0){
                pstm.setInt(5,pr.getIdProduto());
            }
            pstm.execute();
            this.desconectar();
            return true;
            
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
     public Produto getCarregaPorID(int idProduto) throws Exception{
        
        Produto pr = new Produto();
        String sql = "SELECT * FROM produto WHERE idProduto=?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1,idProduto);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            pr.setIdProduto(idProduto);
            pr.setNome(rs.getString("nome"));
            pr.setPreco(rs.getDouble("preco"));
            pr.setDesc(rs.getString("desc"));
            pr.setQtdEstoque(rs.getInt("qtdEstoque"));
            
        }
        this.desconectar();
        return pr;
    }
    
    public boolean deletar (Produto pr){
    
        try{
            String sql = "DELETE FROM produto WHERE idProduto=?";
            
            this.conectar();
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1,pr.getIdProduto());
            pstm.execute();
            this.desconectar();
            return true;
            
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
}

