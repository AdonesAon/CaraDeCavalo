
package model;

import java.util.Date;



public class Usuario {
      
    private int idUsuario;
    private String nome;
    private String cpf;
    private Date nascimento;
    private Perfil perfil;

    public Usuario() {
    }

    public Usuario(int idUsuario, String nome, String cpf, Date nascimento, Perfil perfil) {
        this.idUsuario = idUsuario;
        this.nome = nome;
        this.cpf = cpf;
        this.nascimento = nascimento;
        this.perfil = perfil;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Date getNascimento() {
        return nascimento;
    }

    public void setNascimento(Date nascimento) {
        this.nascimento = nascimento;
    }

    public Perfil getPerfil() {
        return perfil;
    }

    public void setPerfil(Perfil perfil) {
        this.perfil = perfil;
    }

    @Override
    public String toString() {
        return "Usuario{" + "nome=" + nome + '}';
    }
    
    
    
}
