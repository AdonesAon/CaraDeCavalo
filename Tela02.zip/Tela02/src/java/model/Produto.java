
package model;

public class Produto {
    
    
    private int idProduto;
    private String nome;
    private Double preco;
    private String desc;
    private int qtdEstoque;

    public Produto() {
    }

    public Produto(int idProduto, String nome, Double preco, String desc, int qtdEstoque) {
        this.idProduto = idProduto;
        this.nome = nome;
        this.preco = preco;
        this.desc = desc;
        this.qtdEstoque = qtdEstoque;
    }

    public int getIdProduto() {
        return idProduto;
    }

    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getQtdEstoque() {
        return qtdEstoque;
    }

    public void setQtdEstoque(int qtdEstoque) {
        this.qtdEstoque = qtdEstoque;
    }

    @Override
    public String toString() {
        return "Produto{" + "nome=" + nome + '}';
    }
    
    
}
