/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Produto;
import model.ProdutoDAO;

/**
 *
 * @author marce
 */
public class GerenciarProduto extends HttpServlet {

    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
         PrintWriter out = response.getWriter();
        String mensagem = "";
        
        String acao = request.getParameter("acao");
        String idProduto = request.getParameter("idProduto");
        
        Produto pr  = new Produto();
        
        try{
            ProdutoDAO prDAO =  new ProdutoDAO();
            if(acao.equals("alterar")){
                pr = prDAO.getCarregaPorID(Integer.parseInt(idProduto));
                if(pr.getIdProduto()>0){
                    RequestDispatcher disp = getServletContext().getRequestDispatcher("/form_produto.jsp");
                    request.setAttribute("produto", pr);
                    disp.forward(request, response);
                }else{
                    mensagem = "Produto não foi encontrado";
                }
            
            }
            if(acao.equals("deletar")){
                pr.setIdProduto(Integer.parseInt(idProduto));
                if(prDAO.deletar(pr)){
                    mensagem = "Produto deletado com sucesso";
                }else{
                    mensagem = "Erro ao deletar o produto";
                }
            }
        }catch(Exception e){
            out.println(e);
            mensagem = "Erro ao executar";
        }
        out.println("<script type = 'text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='listar_menu.jsp';");
        out.println("</script>");
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        PrintWriter out = response.getWriter();
        
        String idProduto = request.getParameter("idProduto");
        String nome = request.getParameter("nome");
        String preco = request.getParameter("preco");
        String desc = request.getParameter("desc");
        String qtdEstoque = request.getParameter("qtdEstoque");
        
        String mensagem = "";
        
        Produto pr = new Produto();
        
        try{
            ProdutoDAO prDAO = new ProdutoDAO();
            if(!idProduto.isEmpty()){
                pr.setIdProduto(Integer.parseInt(idProduto));
            }
            
            if(nome.equals("")||preco.equals("")||desc.equals("")||qtdEstoque.equals("")){
                mensagem = "Campos obrigatórios  deverão  ser preenchidos";
            }else{
                pr.setNome(nome);
                pr.setPreco(Double.parseDouble(preco));
                pr.setDesc(desc);
                pr.setQtdEstoque(Integer.parseInt(qtdEstoque));
                if(prDAO.gravar(pr)){
                    mensagem = "Gravado com sucesso";
                }else{
                    mensagem = "Erro  ao gravar  o produto";
                }
            }
            
        }catch(Exception e){
            out.println(e);
            mensagem = "Erro ao executar";
        }
        out.println("<script type = 'text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='listar_produto.jsp';");
        out.println("</script>");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
